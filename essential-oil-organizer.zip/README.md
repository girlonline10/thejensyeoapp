# Essential Oil Organizer App
Full-stack React + Node.js + MySQL app for managing essential oils and blends.
